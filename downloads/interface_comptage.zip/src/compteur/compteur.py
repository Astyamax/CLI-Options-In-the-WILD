from . import script_compteur


def compteur_generale(prog):

    options = []
    aides = [
        "--help",
        "-h",
        "-help",
        "help",
        "-?",
        "--usage",
        "--help full",
        "-h full",
        "--help all",
        "-h all",
    ]
    for aide in aides:
        L = script_compteur.lister_commandes(prog, aide)
        if L:
            options += L
    options_uniques = []
    options_uniques = list(set(options))

    return options_uniques
